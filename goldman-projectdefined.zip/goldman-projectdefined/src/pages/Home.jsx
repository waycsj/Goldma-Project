import Navbar from "../components/navbar/Navbar"
import Slider from "../components/slider/slider";


const Home = () => {
  return (
    <>
      <Navbar />
      <Slider />
    </>
  )
}

export default Home;